<?php

return array(

    'conditional_logic' => array(
        'id'       => 'conditional_logic',
        'nicename' => __( 'Conditional Logic', 'ninja-forms-conditional-logic' ),
    )

);
