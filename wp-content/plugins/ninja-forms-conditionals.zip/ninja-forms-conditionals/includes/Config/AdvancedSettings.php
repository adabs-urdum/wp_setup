<?php

return array(

    'conditional_logic' => array(
        'conditions'            => array(
            'name'              => 'conditions',
            'type'              => 'advanced_conditions',
            'label'             => __( 'Conditional Logic', 'ninja-forms-conditional-logic' ),
            'width'             => 'full',
            'group'             => 'primary',
        ),
    )

);
