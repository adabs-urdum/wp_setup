<?php

interface NF_ConditionalLogic_Comparator
{
    public function compare( $comparison, $value );
}